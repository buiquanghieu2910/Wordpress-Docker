---
title: Minimalism Shapes
category: Video
category_slug: video
type: video
image: assets/img/works/work2.jpg
video: https://vimeo.com/97102654
---
